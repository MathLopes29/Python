# Orientações importantes sobre o envio

- Tenha certeza que os arquivos estão na resolução 320x243 (em paisagem)
- Siga o padrão decidido em aula: `ra9999.emocao.jpg`
- Coloque uma boa quantidade de fotos de treino para não dar erros de predição
- Verifique se o Python consegue detectar o rosto antes de enviar

Código para detecção de rosto. Coloque no final do código da aula para verificar se seu rosto está sendo detectado ou não

```python
teste_imagem = '/content/yalefaces/test/ra2008.noglasses.jpg'
face, imagem = detecta_face(network, teste_imagem)
cv2_imshow(imagem)
cv2_imshow(face)
```